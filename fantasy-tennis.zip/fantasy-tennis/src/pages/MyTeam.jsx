import { useState, useEffect } from 'react'
import { supabase } from '../supabase'
import './MyTeam.css'

function computeMultiplier(ranking) {
  return Math.ceil(ranking / 5)
}

export default function MyTeam({ session }) {
  const [roster,   setRoster]   = useState([])
  const [allAtp,   setAllAtp]   = useState([])
  const [loading,  setLoading]  = useState(true)
  const [credits,  setCredits]  = useState(0)

  useEffect(() => {
    async function load() {
      const [{ data: profile }, { data: roster }, { data: atp }] = await Promise.all([
        supabase.from('profiles').select('credits_remaining').eq('id', session.user.id).single(),
        supabase
          .from('roster_players')
          .select('*, atp_players(*)')
          .eq('user_id', session.user.id)
          .order('atp_players(ranking)'),
        supabase.from('atp_players').select('*').order('ranking'),
      ])
      setCredits(profile?.credits_remaining ?? 0)
      setRoster(roster ?? [])
      setAllAtp(atp ?? [])
      setLoading(false)
    }
    load()
  }, [session.user.id])

  if (loading) return <div className="loading-screen">Caricamento…</div>

  const rosterIds = new Set(roster.map(r => r.atp_player_id))

  return (
    <div className="page">
      <header className="page-header">
        <div>
          <h1 className="page-title display">La mia rosa</h1>
          <p className="page-subtitle">{roster.length}/10 giocatori · {credits} crediti rimasti</p>
        </div>
      </header>

      {roster.length === 0 ? (
        <div className="card empty-state">
          <p>Non hai ancora giocatori in rosa.</p>
          <p style={{ color: 'var(--text2)', fontSize: 13, marginTop: 8 }}>
            L'asta viene effettuata prima dell'inizio della stagione.
            Una volta completata, i tuoi 10 giocatori appariranno qui.
          </p>
        </div>
      ) : (
        <div className="roster-grid">
          {roster.map(r => {
            const p = r.atp_players
            const mult = computeMultiplier(p.ranking)
            return (
              <div key={r.id} className="player-card card card-sm">
                <div className="player-card-top">
                  <div className="player-ranking mono">#{p.ranking}</div>
                  <div className="player-mult-badge">
                    <span className="mono">×{mult}</span>
                    <span>molt.</span>
                  </div>
                </div>
                <div className="player-name">{p.name}</div>
                <div className="player-card-bottom">
                  <span className="price-paid mono">{r.price_paid} crediti</span>
                </div>
              </div>
            )
          })}
        </div>
      )}

      {/* ── Full ATP list (for reference / auction use) ── */}
      <div style={{ marginTop: 40 }}>
        <h2 className="display" style={{ fontSize: 28, marginBottom: 16 }}>
          Top 100 ATP — Prezzi asta
        </h2>
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <table className="atp-table">
            <thead>
              <tr>
                <th>Rank</th>
                <th>Giocatore</th>
                <th>Prezzo</th>
                <th>Molt. medio</th>
                <th>In rosa</th>
              </tr>
            </thead>
            <tbody>
              {allAtp.map(p => (
                <tr key={p.id} className={rosterIds.has(p.id) ? 'row-owned' : ''}>
                  <td className="mono">#{p.ranking}</td>
                  <td className="player-col">{p.name}</td>
                  <td className="mono price-col">{p.price}</td>
                  <td className="mono">×{computeMultiplier(p.ranking)}</td>
                  <td>{rosterIds.has(p.id) ? <span className="in-roster-dot">●</span> : null}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
