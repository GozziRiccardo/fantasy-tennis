import { useState, useEffect } from 'react'
import { supabase } from '../supabase'
import './Dashboard.css'

function tournamentBadge(type, status) {
  if (status === 'ongoing')   return <span className="badge badge-live">● Live</span>
  if (status === 'completed') return <span className="badge badge-done">Fine</span>
  const cls = type === 'slam' ? 'badge-slam' : 'badge-masters'
  const lbl = type === 'slam' ? 'Slam' : 'Masters 1000'
  return <span className={`badge ${cls}`}>{lbl}</span>
}

function formatDate(d) {
  return new Date(d).toLocaleDateString('it-IT', { day: 'numeric', month: 'short' })
}

export default function Dashboard({ session }) {
  const [leaderboard,  setLeaderboard]  = useState([])
  const [tournaments,  setTournaments]  = useState([])
  const [myScores,     setMyScores]     = useState([])
  const [loading,      setLoading]      = useState(true)

  useEffect(() => {
    async function load() {
      const [{ data: lb }, { data: tv }, { data: sc }] = await Promise.all([
        supabase.from('leaderboard').select('*'),
        supabase.from('tournaments').select('*').order('start_date'),
        // My last 3 tournament scores
        supabase
          .from('tournament_scores')
          .select(`
            total_points, base_points, captain_bonus, win_bonus, rounds_won,
            picks ( is_captain, multiplier,
              atp_players ( name, ranking ),
              tournaments ( name, type )
            )
          `)
          .eq('picks.user_id', session.user.id)
          .order('computed_at', { ascending: false })
          .limit(12),
      ])
      setLeaderboard(lb ?? [])
      setTournaments(tv ?? [])
      setMyScores(sc ?? [])
      setLoading(false)
    }
    load()
  }, [session.user.id])

  const upcoming = tournaments.filter(t => t.status === 'upcoming').slice(0, 3)
  const ongoing  = tournaments.find(t  => t.status === 'ongoing')

  const myRank = leaderboard.findIndex(u => u.user_id === session.user.id) + 1
  const me     = leaderboard.find(u => u.user_id === session.user.id)

  if (loading) return <div className="loading-screen">Caricamento…</div>

  return (
    <div className="page">
      {/* ── Header ── */}
      <header className="page-header">
        <div>
          <h1 className="page-title display">Classifica</h1>
          <p className="page-subtitle">Stagione 2025 · {leaderboard.length} giocatori</p>
        </div>
        {me && (
          <div className="my-rank-chip">
            <span className="my-rank-pos mono">#{myRank}</span>
            <span className="my-rank-pts mono">{me.total_points} <small>pts</small></span>
          </div>
        )}
      </header>

      <div className="dashboard-grid">
        {/* ── Leaderboard ── */}
        <section>
          <div className="card">
            <div className="leaderboard-list">
              {leaderboard.length === 0 && (
                <p style={{ color: 'var(--text2)', fontSize: 13 }}>Nessun punto ancora. Forza!</p>
              )}
              {leaderboard.map((u, i) => {
                const isMe = u.user_id === session.user.id
                const medals = ['🥇', '🥈', '🥉']
                return (
                  <div key={u.user_id} className={`lb-row ${isMe ? 'lb-row-me' : ''}`}>
                    <div className="lb-pos mono">
                      {i < 3 ? medals[i] : <span className="lb-num">{i + 1}</span>}
                    </div>
                    <div className="lb-name">
                      {u.username}
                      {isMe && <span className="lb-you">tu</span>}
                    </div>
                    <div className="lb-right">
                      <span className="lb-pts mono">{u.total_points}</span>
                      <span className="lb-pts-label">pts</span>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </section>

        {/* ── Right column ── */}
        <aside className="dashboard-aside">

          {/* Current tournament */}
          {ongoing && (
            <div className="card" style={{ marginBottom: 16, borderColor: 'rgba(200,240,0,0.2)' }}>
              <div className="section-label">In corso</div>
              <div className="tournament-highlight">
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                  {tournamentBadge(ongoing.type, ongoing.status)}
                </div>
                <div className="tournament-name display">{ongoing.name}</div>
                <div className="tournament-dates">
                  {formatDate(ongoing.start_date)} — {formatDate(ongoing.end_date)}
                </div>
              </div>
            </div>
          )}

          {/* Upcoming */}
          {upcoming.length > 0 && (
            <div className="card">
              <div className="section-label" style={{ marginBottom: 14 }}>Prossimi tornei</div>
              <div className="upcoming-list">
                {upcoming.map(t => (
                  <div key={t.id} className="upcoming-row">
                    <div className="upcoming-info">
                      {tournamentBadge(t.type, t.status)}
                      <span className="upcoming-name">{t.name}</span>
                    </div>
                    <span className="upcoming-date mono">{formatDate(t.start_date)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* My recent scores */}
          {myScores.length > 0 && (
            <div className="card" style={{ marginTop: 16 }}>
              <div className="section-label" style={{ marginBottom: 14 }}>I miei ultimi punti</div>
              <div className="scores-list">
                {myScores.slice(0, 6).map(s => (
                  <div key={s.id ?? Math.random()} className="score-row">
                    <div className="score-player">{s.picks?.atp_players?.name}</div>
                    <div className="score-detail">
                      <span className="mono" style={{ color: 'var(--text2)', fontSize: 12 }}>
                        {s.rounds_won}R
                        {s.picks?.is_captain ? ' · C' : ''}
                      </span>
                    </div>
                    <div className={`score-pts mono ${s.total_points > 0 ? 'pts-good' : 'pts-zero'}`}>
                      +{s.total_points}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </aside>
      </div>
    </div>
  )
}
